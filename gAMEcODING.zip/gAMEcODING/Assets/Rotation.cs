﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotation : MonoBehaviour
{
    //public float degreeAngle = Random.Range(10.0f, 50.0f);

    public void Generated(int index)
    {
        this.transform.rotation *= Quaternion.Euler(30 * ((index * 2) - 1), 0, 0);
    }
   
}
