﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Resize : MonoBehaviour
{
    public float reScaler = 0.5f;

   public void Generated(int index)
    {
        this.transform.localScale *= reScaler;
    }
}
